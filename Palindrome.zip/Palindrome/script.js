// Grabbing the elements

const inputBox = document.getElementById('inputBox');
const outputBox = document.getElementById('output');
const checkBtn = document.getElementById('checkBtn');

// creating function for checking the palindrome

const checkWord = () => {
    let inputWord = inputBox.value.toLowerCase().trim();
    let palindrome = inputWord.split('').reverse().join('');

    if (inputWord === '') {
        outputBox.textContent = 'Enter word first'
        outputBox.style.color = 'red';
        inputBox.value = '';
    } else if (inputWord === palindrome) {
        outputBox.textContent = `${inputWord} is a palindrome`;
        outputBox.style.color = 'green';
    } else {
        outputBox.textContent = `${inputWord} is not a palindrome`
        outputBox.style.color = 'red';
        inputBox.value = '';
    }

};

// adding event listener to the button

checkBtn.addEventListener('click', checkWord);

