// Grabbing the elements

const quote = document.getElementById('quote');
const author = document.getElementById('author');
const btn = document.getElementById('btn');
const URL = 'https://dummyjson.com/quotes/random';


// creating a function to get the quote using async/await

const getQuote = async () => {

    try {
        const response = await fetch(URL);
        const data = await response.json();

        quote.textContent = `${data.quote}`;
        author.textContent = `${data.author}`;

    }
    catch (error) {
        console.log(error);

    }

};

getQuote();

setInterval(getQuote, 5000);

// adding event listener to the button

btn.addEventListener('click', getQuote);


