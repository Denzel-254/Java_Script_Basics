// Grabing the elements

const btn = document.getElementById('loadUsers');
const userList = document.getElementById('userList');

// API Endpoint

const url = 'https://dummyjson.com/users?limit=5';

// Creating async funtion to fetch the data

const getUsers = async () => {

    try {
        const response = await fetch(url);
        const data = await response.json();

        data.users.forEach(user => {
            const list = document.createElement('li');
            list.textContent = `${user.firstName} ---- ${user.lastName} ---- ${user.email} ---- ${user.phone} ---- ${user.university} `;

            userList.appendChild(list);
        });

    }
    catch (error) {
        console.log(error);

    }

};

// Adding event listener to the button

btn.addEventListener('click', getUsers);

